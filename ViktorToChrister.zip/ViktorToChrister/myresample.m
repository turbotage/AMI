function resampled = myresample(dat)
    resampled = resample(dat,1,4,'Dimension',3);
end