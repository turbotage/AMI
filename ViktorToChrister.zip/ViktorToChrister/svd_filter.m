function svd_dat = svd_filter(svd_dat)
    
end