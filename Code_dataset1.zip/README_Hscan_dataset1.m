Script order of H-scan on datasets 1

To compute scripts of H-scan on datasets 1 proceed according to the 
following instruction:

1. The main script for H-scan development is dataset1.m, containing
data for evaluating and c both contracting and resting conditions
Run this first. An additional script is the myrgdencoder.m compresses 
the data to a normalization between 0 and 1.


2. At the end of the different conditions and before the comparisons there
is a section called "Additional analytical imagery" that is not included 
in the scope of our report but was utilized to better understand the 
signals spatial and temporal intensity propagation.

4. In the end of the script comparisons of the datasets exists, using the 
ranksumtest for testing the equal medians of the samples.

Addendum: Sometimes the climc values are varied across some of the scripts 
so or the exceptions in the functions written will not be caught, 
this is something we did not have time to tend to so just fill it in if it
does not work.

/Hanna Lodin. (Parts taken from Rebeccas README-file)